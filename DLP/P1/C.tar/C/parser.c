/*
  Module:	Parser [For Turing Machine]
  Version:	1.0
  Info:		Impementation of a Parser that reads a file
  			containing turing rules in a given format and
  			stores them in a bi-dimensional matrix.  

  Date:		09-2016
  Author: 	Miguel Mosquera
			Adrián Blanco Costas
  Mail:		miguel.mosquera.perez@udc.es
			adrian.costas@udc.es

*/

#include "parser.h"


//Function to count the number of the lines in the file,
//so we can make an array of fixed size.
int parser_countlines(char * input){
	FILE * fp;
	char * line = NULL;
	size_t len = 0;
	ssize_t read;
	int number_of_lines = 0;

	fp = fopen(input, "r");
	if (fp == NULL)
	{
		perror("Canot open input file\n");
		exit(-1);
	}
	while ((read = getline(&line, &len, fp)) != -1) 
	{
		number_of_lines++;
	}

	fclose(fp);
	if (line)
		free(line);

	return number_of_lines;
}

char ** parser_getrules(char * input, int n_rules){

	int number_of_lines = n_rules;

	char **array_rules = malloc(number_of_lines * sizeof(char *));

	for (int i=0;i<number_of_lines;i++){
		array_rules[i] =  malloc(5* sizeof(char));
	}

	FILE *input_file;
	input_file = fopen(input, "r");

	if (input_file == 0)
	{
		//fopen returns 0, the NULL pointer, on failure
		perror("Can't open input file\n");
		exit(-1);
	}

	int i = 0, j = 0;
	char c;

    while ((c = fgetc(input_file)) != EOF )
    {
    	if ((c == '\n') || (j>4))
    	{


    		i++;
    		j=0;
    		continue;
    	}
 
    	array_rules[i][j] = c;
    	j++;
    }

    
    /*TESTING
    for (i = 0; i < number_of_lines; i++)
    {
    	for (j = 0; j < 5; j++)
    	{
    		printf("%c", array_rules[i][j]);
    	}
    	printf("\n");
    }*/ 	

    fclose(input_file);

    return array_rules;
}