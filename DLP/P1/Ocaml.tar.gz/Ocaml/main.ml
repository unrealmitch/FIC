(*****************************************************)
(*Main of the ocaml program to handle turing machines*)
(*****************************************************)

open Set;;
open Tm;;

exception File_not_provided of string;;
exception String_not_rule of string;;

(*Tail recursive function to append two list*)
let append l1 l2 =
  let rec aux acc l1 l2 =
    match l1, l2 with
    	[], [] -> List.rev acc
    	| [], h :: t -> aux (h :: acc) [] t
    	| h :: t, l -> aux (h :: acc) t l
    in aux [] l1 l2

(*To transform a string into a list of strings*)
let string_to_list str =
  let rec aux i limit =
    if i = limit then []
    else (Char.escaped (String.get str i))::(aux (i + 1) limit)
  in
  aux 0 (String.length str);;

(*To tranform a string into a simbol*)
let str_to_simbol s = match s with
	"B" -> White
	| _ -> Simbol s;;

(*To tranform a string list into a simbol list*)
let rec strlist_to_simbollist l = let rec aux l acc = match l with
	[] -> List.rev acc
	| h::t -> aux t ((str_to_simbol h)::acc)
in aux l [];;

(*To get the tape into a string*)
print_string("Input: ");;
flush stdout;;
let input_str = read_line();;
let input_str_list = string_to_list input_str;;
let input = strlist_to_simbollist input_str_list;; 

(*To transform a string into a movement*)
let str_to_movement s = match s with
	"R" -> Right
	|"L" -> Left
	| _ -> raise (String_not_rule "The movement char has not the correct syntax");;


let tape_to_str l = let rec aux l1 acc = match l1 with
	[] ->  String.concat "" (List.rev acc)
	|White::t -> aux t ("B"::acc)
	|(Simbol a)::t -> aux t (a::acc)
in aux l [];;


(*To transform a string into a Turing machine rule*)
let string_to_tm_aux s = if ((String.length s) < 5) then raise (String_not_rule "The string has not the enough lenght to be transformed into a Turing machine rule") 
	else
		Tm_rule (State (Char.escaped(String.get s 0)), State (Char.escaped(String.get s 1)), str_to_simbol (Char.escaped(String.get s 2)), str_to_simbol(Char.escaped(String.get s 3)), str_to_movement (Char.escaped(String.get s 4)));;


let rec string_to_tm ic l = 
			try 
    			let line = input_line ic in                
    			string_to_tm ic (append l [(string_to_tm_aux line)]);                  
  				
  			with 
  				| End_of_file ->                      
    				close_in_noerr ic;          
    				l;

    			| String_not_rule a ->
    				close_in_noerr ic;           
    				raise (String_not_rule a);;

let turing a = if (Array.length(a) < 2) then raise (File_not_provided "It is mandatory to provide a file name containing the turing machine description") else
	let file = Sys.argv.(1) in
		let ic = open_in file in
			try 
    			let tm = Tm (Set (string_to_tm ic [])) in
    			 match (tm_accepts tm (initialState tm) ([],input) 0) with
    			 	(true,(l1,l2),s) -> print_endline "Accept: yes";   
    								  	print_endline ("Steps: " ^ string_of_int s);
    								  	flush stdout;
    								  	if (Array.length(a)>2) then let outfile = Sys.argv.(2) in
    								  		let oc = open_out outfile in
    								  			Printf.fprintf oc "%s\n" (tape_to_str l1);
    								  			Printf.fprintf oc "%s\n" (tape_to_str l2);
    								  			close_out oc;


    				|(false,(l1,l2),s) -> print_endline "Accept: no";   
    									  print_endline ("Steps: " ^ string_of_int s);
    								  	  flush stdout;
  				
  			with End_of_file ->                      
    			close_in_noerr ic;           
    			raise End_of_file;;

turing Sys.argv;;

 