(********************************************)
(*Implementation of Turing Machines in Ocaml*)
(********************************************)

open Set;;

type simbol =
     Simbol of string
     |White;;

type state = 
	 State of string;;

type tm_movement =
	 Left
   	 |Right;;

type tm_rule = 
	 Tm_rule of (state * state * simbol * simbol * tm_movement)
	 |RuleNull;;

type tm = 
	 Tm of tm_rule set;; 




(*********************************************)
(*****************FOR TESTING*****************)
(*********************************************)

let a = State "A";;
let s = State "S";;
let d = State "D";;
let f = State "F";;
let g = State "G";;
let h = State "H";;
let q = Simbol "q";;
let w = Simbol "w";;
let e = Simbol "e";;
let r = Simbol "r";;
let x = Simbol "X";;
let y = Simbol "Y";;

let rule1 = Tm_rule (a,s,q,x,Right);;
let rule2 = Tm_rule (s,d,w,y,Right);;
let rule3 = Tm_rule (d,h,e,x,Right);;

let tm1 = Tm (Set [rule1;rule2;rule3]);;

let l1 = [];;

let l2 = [q;w;e];;

(**********************************************)
let rule1 = Tm_rule (State "A",State "B",Simbol "a",Simbol "X",Right);;
let rule2 = Tm_rule (State "A",State "E",Simbol "Y",Simbol "Y",Right);;
let rule3 = Tm_rule (State "A",State "H",White,White,Right);;
let rule4 = Tm_rule (State "B",State "B",Simbol "a",Simbol "a",Right);;
let rule5 = Tm_rule (State "B",State "B",Simbol "Y",Simbol "Y",Right);;
let rule6 = Tm_rule (State "B",State "C",Simbol "b",Simbol "Y",Right);;
let rule7 = Tm_rule (State "C",State "C",Simbol "b",Simbol "b",Right);;
let rule8 = Tm_rule (State "C",State "C",Simbol "Z",Simbol "Z",Right);;
let rule9 = Tm_rule (State "C",State "D",Simbol "c",Simbol "Z",Left);;
let rule10 = Tm_rule (State "D",State "A",Simbol "X",Simbol "X",Right);;
let rule11 = Tm_rule (State "D",State "D",Simbol "a",Simbol "a",Left);;
let rule12 = Tm_rule (State "D",State "D",Simbol "b",Simbol "b",Left);;
let rule13 = Tm_rule (State "D",State "D",Simbol "Y",Simbol "Y",Left);;
let rule14 = Tm_rule (State "E",State "E",Simbol "Y",Simbol "Y",Right);;
let rule15 = Tm_rule (State "D",State "D",Simbol "Z",Simbol "Z",Left);;
let rule16 = Tm_rule (State "E",State "E",Simbol "Z",Simbol "Z",Right);;
let rule17 = Tm_rule (State "E",State "H",White,White,Right);;

let tm2 = Tm (Set [rule1;rule2;rule3;rule4;rule5;rule6;rule7;rule8;rule9;rule10;rule11;rule12;rule13;rule14;rule15;rule16;rule17]);;




(****************************************)
(******For the handling of the tape******)
(****************************************)

(*Returns the last element of a list*)
let rec lastof l = match l with
	[] -> White
	|[h] -> h
	|h::t -> lastof t;;

(*Eliminates the last element of a list*)
let extractlast l = let rec aux l1 l2 = match l1,l2 with
	[],_ -> []
	|[h],l2 -> List.rev l2
	|h1::t1,l2 -> aux t1 (h1::l2)
in aux l [];;

(*Moves the head of the tape to the left*)
let tapeleft (l1,l2) = match l1,l2 with
	[],[] -> ([],[White])
	|[],l2 -> ([],White::l2)
	|h1::t1 as l1,[] ->  (extractlast l1,[lastof l1])
	|h1::t1 as l1,l2 -> (extractlast l1,lastof l1::l2);;

(*Moves the head of the tape to the right*)
let taperight (l1,l2) = match l1,l2 with
	[],[] -> ([White],[])
	|[], h2::t2 -> ([h2],t2)
	|h1::t1 as l1,[] -> ((List.append l1 [White]),[])
	|h1::t1 as l1, h2::t2 -> ((List.append l1 [h2]),t2);; 

(*Reads the simbol pointed by the head of the tape*)
let readtape (l1,l2) = match l2 with
	[] -> White
	|[h] -> h
	|h::t -> h;;

(*Depending on the movement moves to the right or to the left*)
let move (l1,l2) m = match m with
	Right -> taperight (l1,l2)
	|Left -> tapeleft (l1,l2);;

(*Writes the specified simbol in the position pointed by the head*)
let write (l1,l2) s = match l2 with
	[] -> (l1,[s])
	|[h] -> (l1,[s])
	|h::t -> (l1,s::t);;




(******************************************)
(*****For handling the Turing Machine*****)
(******************************************)

(*Gets the initial state, wich is in the first rule*)
let initialState_aux (Set rules) = match rules with
	(Tm_rule(a,_,_,_,_))::_ -> a;;

let initialState (Tm machine) = initialState_aux machine;;



(*Returns true and the matching rule if it founds it,
if not, returns false and a null rule*)
let rec rule_accept_aux (Set rules) current input= match rules with
	 [] -> (false,RuleNull)
	 |[Tm_rule(cs,ns,csimb,nsimb,mov) as rule] -> if ((current=cs) && (input=csimb)) then (true,rule) else (false,RuleNull)
	 |Tm_rule(cs,ns,csimb,nsimb,mov) as rule::t -> if ((current=cs) && (input=csimb)) then (true,rule) else rule_accept_aux (Set t) current input;;

let rule_accept (Tm machine) current input = rule_accept_aux machine current input;;


(*Return true if the machine accepts the input or false if it doesn't,
it also return the final state of the tape*)
let rec tm_accepts tm current (l1,l2) steps = let input = readtape (l1,l2) in
	match (rule_accept tm current input) with
		(false,_) -> (false,(l1,l2),steps)
		|(true,Tm_rule(_,d,_,x,m)) -> if (d=State "H") then (true,(move (write (l1,l2) x) m),(steps+1)) else tm_accepts tm d (move (write (l1,l2) x) m) (steps+1);;
																										 



