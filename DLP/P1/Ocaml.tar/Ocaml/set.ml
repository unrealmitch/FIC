(***************************************)
(*Implementation of sets based on lists*)
(***************************************)

type 'a set = Set of 'a list;; 

(***********************************)

let empty_set = Set [];;

(***********************************)

let is_empty = function
     Set [] -> true
   | _           -> false;;

(**********************************)

let rec belongs a = function
     Set []     -> false
   | Set (x::l) -> (x = a) or (belongs a (Set l));;


(**********************************)


let add a (Set l) = 
   if belongs a (Set l) then
      Set l
   else
      Set (a::l)
   ;;

