#ifndef tape_h
#define tape_h

#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DEBUG_TAPE 0

typedef enum { false, true } bool;

//Structs of doubly linked list [as tape]
typedef struct dl_item {
	char data;
	struct dl_item *left;
	struct dl_item *rigth;
}dl_item;

typedef struct dl_tape {
	dl_item *head;
	int size;
}dl_tape;

/*
typedef struct dl_tape_output{
	char *output_left;
	char *output_rigth;
}dl_tape_output; */

//Init Functions
dl_tape* dl_create();

//Read Functions
char dl_read_head(dl_tape *tape);

//Move Functions
bool dl_mod_head(dl_tape *tape, char data);
bool dl_mov_left(dl_tape *tape);
int dl_mov_begin(dl_tape *tape);
int dl_mov_end(dl_tape *tape);

//Add Functions
bool dl_add_from_empty(dl_tape *tape, char data);
bool dl_add_from_head(dl_tape *tape, char data, char dir);
bool dl_add_from_side(dl_tape *tape, char data, char dir);

//Turing Machine Functions
bool tp_init(dl_tape *tape, char *input);
bool tp_write_move(dl_tape *tape, char data, char dir);
void tp_write_output(dl_tape *tape, char *file_output);
//dl_tape_output tp_get_output(dl_tape *tape);

//Debug prupose
void dl_print(dl_tape *tape);
void dl_free(dl_tape *tape);

#endif