/*
  Program:	Turing Machine
  Version:	1.2
  Info:		Impementation of a Turing Machine in C
  			The operation of this program simulate a
  			Turing Machine

  Date:		09-2016
  Author: 	Miguel Mosquera
			Adrián Blanco Costas
  Mail:		miguel.mosquera.perez@udc.es
			adrian.costas@udc.es

*/

#include "parser.h"
#include "tape.h"
#include <time.h>

#define debug false
#define debug_t false

double microsec() { 
	struct timeval t;
	if (gettimeofday(&t, NULL) < 0 )
		return 0.0;
	return (t.tv_usec + t.tv_sec * 1000000.0);
}

int main (int argc, char **argv){

	if(argc<2){
		printf("Error: Please choose rules' document (input file)\n");
		exit(-1);
	}else{

		//Init Turing Machine [Load rules and init the tape]
		char * input_file = argv[1];
		int n_rules = parser_countlines(input_file);
		char ** rules = parser_getrules(input_file,n_rules);
		dl_tape *tape = dl_create();

		//if (argc<4){								//Input by keyboard [inside program]
			char input[1024] = "B"; 
			printf("Input: ");
			scanf("%[^\n]s",&input);
			if(input == NULL){
				tp_init(tape, 'B');
			}else
				tp_init(tape, input);
		/*
		}else{
			printf("Input(AR):%s\n", argv[3]);		//Input by argument [3r arg = input]
			tp_init(tape, argv[2]);
		}
		*/

		clock_t start = clock();

		int i = 0;									//Actual Rule
		int n_steps = 0;
		char state_tp = rules[0][0];
		char input_tp = dl_read_head(tape);

		while(state_tp != 'H' && i < n_rules){

			if( (state_tp==rules[i][0]) && (input_tp==rules[i][2]) ){

				if(debug){
					dl_print(tape);
					printf("\n [R:%d] %c -> %c  (%c,%c,%c)\n",i,state_tp,rules[i][1], input_tp, rules[i][3], rules[i][4]);
					printf("\n");
				}

				tp_write_move(tape,rules[i][3],rules[i][4]);
				state_tp = rules[i][1];
				input_tp = dl_read_head(tape);
				n_steps++;
				i=-1;
			}
			i++;
		}

		
		if(debug) dl_print(tape);

		if(state_tp == 'H'){
			printf("Accept: yes\n");
		} else{
			printf("Accept: no\n");
		}

		printf("Steps: %d\n", n_steps);

		if(debug_t)
			printf("Time: %f\n", ((double)clock() - start) / CLOCKS_PER_SEC);
		
		if(argc > 2)
				tp_write_output(tape, argv[2]);
		
		
		
		for(int j = 0; j< n_rules;j++)
			free(rules[j]);
		free(rules);

		dl_free(tape);
		free(tape);
		
		
	}
}
