/*
  Module:	Turing Machine Tape [Doubly linked list]
  Version:	1.0
  Info:		Impementation of a Tape (with doubly linked list) that
  			works as a tape of a Turing Machine (and the code refects
  			this way of work)

  Date:		09-2016
  Author: 	Miguel Mosquera
			Adrián Blanco Costas
  Mail:		miguel.mosquera.perez@udc.es
			adrian.costas@udc.es
*/

#include "tape.h"

dl_tape* dl_create(){

	dl_tape *tape;
	if ((tape = malloc(sizeof(dl_tape))) == NULL){
		if (DEBUG_TAPE) printf("# ERROR: NOT ENOUGHT MEMORY\n");
		return NULL;
	}

	tape->head = NULL;
	//tape->first = NULL;
	//tape->last = NULL;
	tape->size = 0;
	return tape;


}

char dl_read_head(dl_tape *tape){
	if(tape->head !=NULL)
		return tape->head->data;
	else
		return 'B';
}

bool dl_mod_head(dl_tape *tape, char data){
	if(tape->head == NULL){
		if (DEBUG_TAPE) printf("# ERROR: EMPTY TAPE\n");
		return false;
	}

	tape->head->data = data;
	return true;
}

/*
bool dl_mod_left(dl_tape *tape, char data){
	if( (tape->head == NULL) && (tape->head->left == NULL) ){
		if (DEBUG_TAPE) printf("# ERROR: Empty Tape or just have one item\n");
		return false;
	}

	strcpy (tape->head->left->data, &data);
	return true;
}

bool dl_mod_rigth(dl_tape *tape, char data){
	if( (tape->head == NULL) && (tape->head->rigth == NULL) ){
		if (DEBUG_TAPE) printf("# ERROR: Empty Tape or just have one item");
		return false;
	}

	strcpy (tape->head->left->rigth, &data);
	return true;
}
*/

bool dl_mov_left(dl_tape *tape){
	if( (tape->head == NULL) || (tape->head->left == NULL) ){
		if (DEBUG_TAPE) printf("# ERROR | Move Left: Empty Tape or just have one item");
		return false;
	}

	tape->head = tape->head->left;
	return true;
}

bool dl_mov_rigth(dl_tape *tape){
	if( (tape->head == NULL) || (tape->head->rigth == NULL) ){
		if (DEBUG_TAPE) printf("# ERROR | Move Rigth: Empty Tape or just have one item");
		return false;
	}

	tape->head = tape->head->rigth;
	return true;
}

int dl_mov_begin(dl_tape *tape){
	int head = 0;

	if (tape == NULL || tape->head == NULL || tape->size == 1)
		return 0;

	while(tape->head->left != NULL){
		head++;
		tape->head = tape->head->left;
	}

	return head;
	/*
	tape->head = tape->first;
	*/
}

int dl_mov_end(dl_tape *tape){
	int n_head = 0;
	
	if (tape == NULL || tape->head == NULL || tape->size == 1)
		return 0;

	while(tape->head->rigth != NULL){
		//printf("M:%c->%c\n", tape->head->data, tape->head->rigth->data);
		n_head++;
		tape->head = tape->head->rigth;
	}

	return n_head;
	/*
	tape->head = tape->last;
	*/
}


bool dl_add_from_empty(dl_tape *tape, char data){
	if (tape->head != NULL)
		return false;

	dl_item *new_item;

	if ( (new_item = malloc(sizeof(dl_item))) == NULL){
		if (DEBUG_TAPE) printf("# ERROR: NOT ENOUGHT MEMORY\n");
		return false;
	}

	new_item->data = data;
	new_item->left = NULL;
	new_item->rigth = NULL;
	tape->head = new_item;
	//tape->first = item;
	//tape->last = item;
	tape->size = 1;

	return true;
}

bool dl_add_from_head(dl_tape *tape, char data, char dir){
	if (tape->head == NULL){
		dl_add_from_empty(tape, data);
		return true;
	}

	dl_item *new_item;

	if ((new_item = malloc(sizeof(dl_item))) == NULL){
		if (DEBUG_TAPE) printf("# ERROR: NOT ENOUGHT MEMORY\n");
		return false;
	}

	new_item->data = data;

	if(dir=='L'){
		new_item->rigth = tape->head;
		if ( (new_item->left = tape->head->left) != NULL ){		//Illegal function for one tape
			if (DEBUG_TAPE) printf("# Warning: Caution, illegal action (adding in middle) in a tape\n");
			new_item->left->rigth = new_item;
			//tape->first = new_item->left;
		} else{
			//tape->first = new_item;
		}

		tape->head->left = new_item;
	} else if(dir=='R'){
		new_item->left = tape->head;
		if ( (new_item->rigth = tape->head->rigth) != NULL ){		//Illigal function for one tape
			if (DEBUG_TAPE) printf("# Warning: Caution, illegal action (adding in middle) in a tape\n");
			new_item->rigth->left = new_item;
			//tape->last = new_item->rigth;			
		} else{
			//tape->last = new_item;
		}

		tape->head->rigth = new_item;

	} else{
		return false;
	}

	tape->size++;
	return true;
}

bool dl_add_from_side(dl_tape *tape, char data, char dir){
	
	if (tape->head == NULL){
		dl_add_from_empty(tape, data);
		return true;
	}

	dl_item *new_item;

	if ((new_item = malloc(sizeof(dl_item))) == NULL){
		if (DEBUG_TAPE) printf("# ERROR: NOT ENOUGHT MEMORY\n");
		return false;
	}

	new_item->data = data;

	if(dir=='L'){
		int n_mov = dl_mov_begin(tape);
		new_item->rigth = tape->head;
		new_item->left = NULL;
		tape->head->left = new_item;
		for(;n_mov>0;n_mov--)
			dl_mov_rigth(tape);

	} else if(dir=='R'){
		int n_mov = dl_mov_end(tape);
		new_item->left = tape->head;
		new_item->rigth = NULL;
		tape->head->rigth = new_item;
		for(;n_mov>0;n_mov--)
			dl_mov_left(tape);

	} else{
		if (DEBUG_TAPE) printf("# ERROR: NOT ACCEPTED MOVE OPERATION (L | R), not: %d\n", dir);
		return false;
	}

	tape->size++;
	return true;
}

void dl_print(dl_tape *tape){

	for(int i = dl_mov_begin(tape);i>0;i--){
		printf("%c ", tape->head->data);
		dl_mov_rigth(tape);
	}

	printf("\n");
	printf("(H):%c ", tape->head->data);
	printf("\n");

	int j = 0;

	while(tape->head != NULL && tape->head->rigth != NULL){
		j++;
		tape->head = tape->head->rigth;
		printf("%c ", tape->head->data);
	}

	for(;j>0;j--)
			dl_mov_left(tape);

	printf("\n");
}

/**************************************/
/*	 FUNCTIONS FOR TURING TAPE (tp)   */
/**************************************/

bool tp_init(dl_tape *tape, char *input){
	if (tape!=NULL){
		//free(tape);
		//dl_create(tape);
		int len = strlen(input);
		for(int i=0; i<len; i++){

			if(!dl_add_from_side(tape,input[i],'R'))
				return false;
		}
		return true;
	}else{
		if (DEBUG_TAPE) printf("# ERROR: First create the tape");
		return false;
	}
}

/*
dl_tape* tp_init(char *input){
	if ( (dl_tape *tape = dl_create()) != NULL)
		tp_init(tape,input);
}
*/

bool tp_write_move(dl_tape *tape, char data, char dir){
	if(dl_mod_head(tape, data)){
		if (dir == 'L'){
			if (tape->head->left == NULL)
				dl_add_from_head(tape,'B', 'L');	//In case that the head is the last item, we add one more with 'B' (Null Value)
			return dl_mov_left(tape);
		} else if (dir == 'R'){
			if (tape->head->rigth == NULL)
				dl_add_from_head(tape,'B', 'R');	//In case that the head is the last item, we add one more with 'B' (Null Value)
			return dl_mov_rigth(tape);
		} else {
			if (DEBUG_TAPE) printf("# ERROR: NOT ACCEPTED MOVE OPERATION (L | R), not: %d", dir);
			return false;	
		}

	}else
		return false;
}

void tp_write_output(dl_tape *tape, char *file_output){

	FILE* output_file;
	output_file = fopen(file_output, "wt");

	int output_head = dl_mov_begin(tape);

	for(int i=0;i<output_head;i++){
		fputc(tape->head->data, output_file);
		dl_mov_rigth(tape);
		//free(tape->head->left);
	}

	fputs("\n", output_file);

	do{
		fputc(tape->head->data, output_file);
		//free(tape->head->left);
	}while(dl_mov_rigth(tape));

	fputs("\n", output_file);
	fclose(output_file);
}

void dl_free(dl_tape *tape){
	dl_mov_begin(tape);

	while(tape->head->rigth != NULL){
		dl_mov_rigth(tape);
		free(tape->head->left);
	}
	free(tape->head);
}