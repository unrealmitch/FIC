#ifndef parser_h
#define parser_h

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>

int parser_countlines(char * input);
char ** parser_getrules(char * input, int n_rules);

#endif
