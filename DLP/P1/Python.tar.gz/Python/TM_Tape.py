#!/usr/bin/env python

'''
	Module:	Turing Machine Tape 
	Version:	1.0

	Date:		10-2016
  Author: 	Miguel Mosquera
			Adrián Blanco Costas
  Mail:		miguel.mosquera.perez@udc.es
			adrian.costas@udc.es
'''

import sys
	
class TM_Tape:
	def __init__(self, input_string=[]):
		self.tape = []
		self.pos = 0
		if len(input_string) > 0:
			for data in input_string:
				self.tape.append(data)
		else:
			self.tape.append('B')
	
	def read(self):
			return self.tape[self.pos]

	def move_write(self, data, direc):
		self.tape[self.pos] = data
			
		if direc == "L":
			self.mov_left()
		elif direc == "R":
			self.mov_right()
		else: raise MachineTapeException ("# ERROR: NOT ACCEPTED MOVE OPERATION (L | R)")
		

	def mov_left(self):
		if self.pos <= 0: 
			self.tape.insert(0, 'B')
			self.pos = 0
		else:
			self.pos += -1
	
	def mov_right(self):
		self.pos += 1
		if self.pos >= len(self.tape): self.tape.append('B')

	def save(self, output_file):
		outfile = open(output_file, 'w')
		for i in range(len(self.tape)):
			if i == self.pos:
				outfile.write("\n")
			outfile.write(self.tape[i])
		outfile.write("\n")
		outfile.close()
