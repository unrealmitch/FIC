#!/usr/bin/env python3

'''
	Program:	Turing Machine
	Version:	1.0
	Info:		Impementation of a Turing Machine in Python3
	Input:		"Input File of Rules" "[Output File for Tape Result]" 

	Date:		10-2016
  Author: 	Miguel Mosquera
			Adrián Blanco Costas
  Mail:		miguel.mosquera.perez@udc.es
			adrian.costas@udc.es
'''

import sys
from time import time

exec(open("./TM_Tape.py").read())
#import TM_Tape

class TuringMachine:
	def __init__(self, input_string, rules):
		self.tape = TM_Tape(input_string)
		self.rules = rules	#[2] State_In [3] State_Out [4] Char_In [5] Char_Out [6] Direction
		self.state = self.rules[0][2]
		self.goal = 'H'
		self.steps = 0

	def transition(self, state_in, char_in):
		for rule in self.rules:
			if state_in == rule[2] and char_in == rule[4]:
				#print("Rule:", rule)

				self.tape.move_write(rule[5], rule[6])
				self.steps += 1
				self.state = rule[3]
				if self.state == 'H':
					return False
				else:
					return True
		return False	

	def start(self):
		i_exit = True;

		while(i_exit):
			i_exit = self.transition(self.state, self.tape.read())

	def end(self, output_file=""):
		if self.state == 'H':
			print("Accept: yes")
		else:
			print("Accept: no")

		print("Steps:", self.steps)

		if output_file != "" : self.tape.save(output_file)

def main():


	if len(sys.argv) < 2:
		print("Error: Please choose rules' document (input file)")
		sys.exit(0)
	elif len(sys.argv) < 4:
		input_file= sys.argv[1]
		with open(input_file) as file:
			rules = [ str(l.strip().split()) for l in file ]

		print("Input: ", end='')
		input_tape = input()

		start = time()

		tm_unit = TuringMachine(input_tape, rules)
		tm_unit.start()
		
		#print('Time: ', time() - start) #En segundos

		if len(sys.argv) != 3:
			tm_unit.end() 
		else:  
			tm_unit.end(sys.argv[2])
			
		sys.exit(0)
	else:
		print("Error: Bad Arguments: turing input-file-rules [output-file-tape]")
		sys.exit(0)

if __name__ == "__main__":
	main()